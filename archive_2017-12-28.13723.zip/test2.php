<?php
echo (date("l dS of F Y h:I:s A"));
?>